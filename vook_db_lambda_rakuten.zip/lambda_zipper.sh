zip -r vook_db_lambda_rakuten . -x ".env/*" -x ".git/*" -x "*/.DS_Store/*" -x "*/.ipynb_checkpoints/*" -x "*/__pycache__/*" -x ".flake8"
