zip -r vook_db_lambda_rakuten.zip . -x ".env/*" -x ".git/*"
