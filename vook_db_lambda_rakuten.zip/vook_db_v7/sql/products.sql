SELECT
        *
FROM
    products
