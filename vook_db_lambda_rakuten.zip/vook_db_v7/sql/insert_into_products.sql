INSERT INTO products (id,name,url,price,knowledge_id,platform_id,size_id,created_at,updated_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
