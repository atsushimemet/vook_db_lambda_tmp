import os

import pymysql

if "AWS_LAMBDA_FUNCTION_NAME" in os.environ:
    # Lambda環境用のクライアント初期化
    print("Now: Lambda env")
    SSH_PKEY_PATH = ".ssh/vook-rails-ssh-key.pem"
else:
    print("Now: Local env")
    SSH_PKEY_PATH = "~/.ssh/vook-rails-ssh-key.pem"
# Yahoo
sid = 3649680
pid = 888462484
AppId = "vintagelevislist"
ClientId = "dj00aiZpPXY0ZG1sbTBRT2RmeCZzPWNvbnN1bWVyc2VjcmV0Jng9MDg-"
ClientSecret = "muGmtqb78GxNE9rUJi9BV0mXXG10rEwPGbbTET4j"

# Rakuten
CLIENT_ME = {
    "APPLICATION_ID": "1040242227042771333",
    "APPLICATION_SECRET": "7bfda08e898e630281e30b603a1b86cdfbdce4c4",
    "AFF_ID": "33a2906e.1076e2ef.33a2906f.06927704",
}


def get_ec2_config():
    return {
        "host_name": "3.114.154.242",
        "ec2_port": 22,
        "ssh_username": "ec2-user",
        "ssh_pkey": SSH_PKEY_PATH,
        "rds_end_point": "vook-rails-db.ctutkiavfpne.ap-northeast-1.rds.amazonaws.com",
        "rds_port": 3306,
    }


def get_rds_config(port):
    return {
        "user": "root",
        "password": "rds-vook",
        "port": port,
        "host": "localhost",
        "database": "vook_web_v3_production",
        "charset": "utf8mb4",
        "cursorclass": pymysql.cursors.DictCursor,
    }


def put_ec2_config():
    return {
        "host_name": "3.114.154.242",
        "ec2_port": 22,
        "ssh_username": "ec2-user",
        "ssh_pkey": SSH_PKEY_PATH,
        # "rds_end_point": "vook-rails-db-dev-1.ctutkiavfpne.ap-northeast-1.rds.amazonaws.com", # NOTE:dev setting
        "rds_end_point": "vook-rails-db.ctutkiavfpne.ap-northeast-1.rds.amazonaws.com",
        "rds_port": 3306,
    }


# 検証dvに格納
def get_rds_config_for_put(port):
    return {
        "user": "root",
        "password": "rds-vook",
        "port": port,
        "host": "localhost",
        "database": "vook_web_v3_development",
        "charset": "utf8mb4",
        "cursorclass": pymysql.cursors.DictCursor,
    }


# def get_ec2_config():
#     return {
#         "host_name": "54.199.201.208",
#         "ec2_port": 22,
#         "ssh_username": "ec2-user",
#         "ssh_pkey": SSH_PKEY_PATH,
# "rds_end_point": "vook-rails-db.ctutkiavfpne.ap-northeast-1.rds.amazonaws.com", # noqa
#         "rds_port": 3306,
#     }


# def get_rds_config(port):
#     return {
#         "user": "root",
#         "password": "rds-vook",
#         "port": port,
#         "host": "localhost",
#         "database": "vook_web_v3_production",
#         "charset": "utf8mb4",
#         "cursorclass": pymysql.cursors.DictCursor,
#     }

s3_bucket = "vook-vook"
s3_file_name_products_raw_prev = "lambda_output/products_raw_prev.csv"
